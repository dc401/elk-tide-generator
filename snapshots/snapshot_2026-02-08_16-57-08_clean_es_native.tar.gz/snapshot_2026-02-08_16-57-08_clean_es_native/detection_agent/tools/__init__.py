"""Tools for detection agent"""

from .load_cti_files import load_cti_files

__all__ = ["load_cti_files"]
