# Production-approved Sigma detection rules
